package com.evernote.coding.exercise.utils;

import java.util.TimerTask;

/**
 * Created by SuryaSelvaraj on 6/19/17.
 */
public class TimerTaskExample extends TimerTask
{
    @Override
    public void run() {
        System.out.println("Run Me ~");
    }
}
